package com.server.webhooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebhooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
